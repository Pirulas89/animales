import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas básicas para Cliente.
 */
public class ClienteTest {

    @Test
    void testCargaClase() {
        assertDoesNotThrow(() -> Class.forName("Cliente"));
    }
}
