import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas básicas para MedicinaDAO.
 */
public class MedicinaDAOTest {

    @Test
    void testCargaClase() {
        assertDoesNotThrow(() -> Class.forName("MedicinaDAO"));
    }
}
