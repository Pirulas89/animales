import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas básicas para Medicina.
 */
public class MedicinaTest {

    @Test
    void testCargaClase() {
        assertDoesNotThrow(() -> Class.forName("Medicina"));
    }
}
