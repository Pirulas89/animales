import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas básicas para App.
 */
public class AppTest {

    @Test
    void testCargaClase() {
        assertDoesNotThrow(() -> Class.forName("App"));
    }
}
