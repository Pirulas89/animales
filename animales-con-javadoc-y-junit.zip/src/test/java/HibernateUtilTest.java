import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas básicas para HibernateUtil.
 */
public class HibernateUtilTest {

    @Test
    void testCargaClase() {
        assertDoesNotThrow(() -> Class.forName("HibernateUtil"));
    }
}
