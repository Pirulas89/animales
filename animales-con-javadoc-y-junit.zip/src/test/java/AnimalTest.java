import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas básicas para Animal.
 */
public class AnimalTest {

    @Test
    void testCargaClase() {
        assertDoesNotThrow(() -> Class.forName("Animal"));
    }
}
