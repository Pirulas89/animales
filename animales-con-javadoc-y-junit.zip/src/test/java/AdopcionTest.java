import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas básicas para Adopcion.
 */
public class AdopcionTest {

    @Test
    void testCargaClase() {
        assertDoesNotThrow(() -> Class.forName("Adopcion"));
    }
}
