import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas básicas para AnimalDAO.
 */
public class AnimalDAOTest {

    @Test
    void testCargaClase() {
        assertDoesNotThrow(() -> Class.forName("AnimalDAO"));
    }
}
