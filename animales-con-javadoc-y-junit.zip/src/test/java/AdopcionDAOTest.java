import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas básicas para AdopcionDAO.
 */
public class AdopcionDAOTest {

    @Test
    void testCargaClase() {
        assertDoesNotThrow(() -> Class.forName("AdopcionDAO"));
    }
}
