import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas básicas para ClienteDAO.
 */
public class ClienteDAOTest {

    @Test
    void testCargaClase() {
        assertDoesNotThrow(() -> Class.forName("ClienteDAO"));
    }
}
