package com.hibernate.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.hibernate.model.Cliente;
import com.hibernate.util.HibernateUtil;

/**
 * DAO para operaciones CRUD de clientes.
 */
public class ClienteDAO {

    /**


     * Método insertCliente.


     * @param c parámetro de entrada.


     */

    public void insertCliente(Cliente c) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.merge(c);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    /**


     * Método updateCliente.


     * @param c parámetro de entrada.


     */

    public void updateCliente(Cliente c) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.merge(c);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    /**


     * Método deleteCliente.


     * @param id parámetro de entrada.


     */

    public void deleteCliente(int id) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Cliente c = session.find(Cliente.class, id);
            if (c != null) {
                session.remove(c);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    /**


     * Método selectClienteById.


     * @param id parámetro de entrada.


     * @return resultado de la operación.


     */

    public Cliente selectClienteById(int id) {
        Transaction transaction = null;
        Cliente c = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            c = session.find(Cliente.class, id);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
        return c;
    }

    /**


     * Método selectAllCliente.


     * @return resultado de la operación.


     */

    public List<Cliente> selectAllCliente() {
        Transaction transaction = null;
        List<Cliente> clientes = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            clientes = session.createQuery("from Cliente", Cliente.class).getResultList();
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
        return clientes;
    }
}